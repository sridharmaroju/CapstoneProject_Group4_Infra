import json
import os
import boto3
import mysql.connector
from datetime import datetime
from mysql.connector import Error

secrets_client = boto3.client("secretsmanager")

DB_SECRET = os.environ.get("DB_SECRET")
DB_INFO = os.environ.get("DB_INFO")


def get_db_secret():
    print("DB_SECRET: ", DB_SECRET)
    response_DB_SECRET = secrets_client.get_secret_value(SecretId=DB_SECRET)
    print("response_DB_SECRET: ", response_DB_SECRET)
    return json.loads(response_DB_SECRET["SecretString"])

def get_db_info():
    print("DB_INFO: ", DB_INFO)
    response_DB_INFO = secrets_client.get_secret_value(SecretId=DB_INFO)
    print("response_DB_INFO: ", response_DB_INFO)
    return json.loads(response_DB_INFO["SecretString"])


def deduct(payload, db_secret, db_info):
    connection = None
    
    INIT_TYPE = 1
    TOP_UP_TYPE = 2
    DEDUCT_TYPE = 3
    
    try:
        connection = mysql.connector.connect(
            host=db_info["host"],
            user=db_secret["username"],
            password=db_secret["password"],
            database=db_info["database"],
            port=db_info.get("port", 3306),
        )

        cursor = connection.cursor()

        card_id = payload["Card_Id"]
        amount = payload["Amount"]

        # 1. Update card balance
        update_balance_sql = """
            UPDATE CARDS
            SET BALANCE = BALANCE - %s
            WHERE CARD_ID = %s
        """
        cursor.execute(update_balance_sql, (amount, card_id))

        # Ensure card exists
        if cursor.rowcount == 0:
            raise Exception(f"Card not found: {card_id}")

        # 2. Insert transaction record (optional but recommended)
        insert_transaction_sql = """
            INSERT INTO TRANSACTIONS
            (CARD_ID, TYPE, AMOUNT, TRANSACTION_DATETIME)
            VALUES (%s, %s, %s, %s)
        """
        cursor.execute(
            insert_transaction_sql,
            (
                card_id,
                DEDUCT_TYPE,
                amount,
                datetime.utcnow()
            )
        )

        connection.commit()

    except Error as e:
        if connection:
            connection.rollback()
        raise e

    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()


def lambda_handler(event, context):
    db_secret = get_db_secret()
    db_info = get_db_info()

    for record in event["Records"]:
        body = json.loads(record["body"])
        deduct(body, db_secret, db_info)

    return {
        "statusCode": 200,
        "body": "Records inserted successfully"
    }