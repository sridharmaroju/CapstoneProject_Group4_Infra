import json
import os
import boto3
import mysql.connector
from datetime import datetime
from mysql.connector import Error

secrets_client = boto3.client("secretsmanager")

DB_SECRET = os.environ.get("DB_SECRET")
DB_INFO = os.environ.get("DB_INFO")

def get_db_secret():
    print("DB_SECRET: ", DB_SECRET)
    response_DB_SECRET = secrets_client.get_secret_value(SecretId=DB_SECRET)
    print("response_DB_SECRET: ", response_DB_SECRET)
    return json.loads(response_DB_SECRET["SecretString"])

def get_db_info():
    print("DB_INFO: ", DB_INFO)
    response_DB_INFO = secrets_client.get_secret_value(SecretId=DB_INFO)
    print("response_DB_INFO: ", response_DB_INFO)
    return json.loads(response_DB_INFO["SecretString"])


def get_cards(user_id, db_secret, db_info):
    connection = None
    
   
    try:
        connection = mysql.connector.connect(
            host=db_info["host"],
            user=db_secret["username"],
            password=db_secret["password"],
            database=db_info["database"],
            port=db_info.get("port", 3306),
        )

        cursor = connection.cursor(dictionary=True)

        sql = """
        SELECT *
        FROM CARDS
        WHERE USER_ID = %s
        """

        cursor.execute(sql, (user_id,))
        cards = cursor.fetchall()
        
        return cards

    except Error as e:
        if connection:
            connection.rollback()
        raise e

    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()


def lambda_handler(event, context):
    db_secret = get_db_secret()
    db_info = get_db_info()

    # Extract JSON payload from API Gateway POST
    try:
        body = event.get("body")
        if body:
            payload = json.loads(body)
        else:
            payload = event  # fallback

        user_id = payload.get("User_Id")
        if not user_id:
            return {
                "statusCode": 200,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({
                    "cards": [],
                    "message": "User_Id not provided"
                })
            }

        result = get_cards(user_id, db_secret, db_info)

        # Always return HTTP 200
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json",
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Headers": "Content-Type,Authorization",
                        "Access-Control-Allow-Methods": "OPTIONS,POST"},
            "body": json.dumps(result, default=str)
        }

    except Exception as e:
        # Catch unexpected errors
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json",
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Headers": "Content-Type,Authorization",
                        "Access-Control-Allow-Methods": "OPTIONS,POST"},
            "body": json.dumps({
                "cards": [],
                "error": str(e)
            })
        }