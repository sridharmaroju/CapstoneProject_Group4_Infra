import json
import os
import boto3
import mysql.connector
from mysql.connector import Error

secrets_client = boto3.client("secretsmanager")

DB_SECRET = os.environ.get("DB_SECRET")
DB_INFO = os.environ.get("DB_INFO")


def get_db_secret():
    print("DB_SECRET: ", DB_SECRET)
    response_DB_SECRET = secrets_client.get_secret_value(SecretId=DB_SECRET)
    print("response_DB_SECRET: ", response_DB_SECRET)
    return json.loads(response_DB_SECRET["SecretString"])

def get_db_info():
    print("DB_INFO: ", DB_INFO)
    response_DB_INFO = secrets_client.get_secret_value(SecretId=DB_INFO)
    print("response_DB_INFO: ", response_DB_INFO)
    return json.loads(response_DB_INFO["SecretString"])


def insert_card(payload, db_secret, db_info):
    connection = None
    print("host: ", db_info["host"])
    print("database: ", db_info["database"])
    print("username: ", db_secret["username"])
    print("password: ", db_secret["password"])
    
    
    try:
        connection = mysql.connector.connect(
            host=db_info["host"],
            user=db_secret["username"],
            password=db_secret["password"],
            database=db_info["database"],
            port=db_info.get("port", 3306),
        )

        cursor = connection.cursor()

        sql = """
        INSERT INTO CARDS (CARD_ID, USER_ID, BALANCE)
        VALUES (%s, %s, %s)
        """

        values = (
            payload["Card_Id"],
            payload["User_Id"],
            payload["Balance"],
        )

        cursor.execute(sql, values)
        connection.commit()

    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()


def lambda_handler(event, context):
    db_secret = get_db_secret()
    db_info = get_db_info()

    for record in event["Records"]:
        body = json.loads(record["body"])
        insert_card(body, db_secret, db_info)

    return {
        "statusCode": 200,
        "body": "Records inserted successfully"
    }