import json
import os
import boto3
import mysql.connector
from datetime import datetime
from mysql.connector import Error

secrets_client = boto3.client("secretsmanager")

DB_SECRET = os.environ.get("DB_SECRET")
DB_INFO = os.environ.get("DB_INFO")


def get_db_secret():
    print("DB_SECRET: ", DB_SECRET)
    response_DB_SECRET = secrets_client.get_secret_value(SecretId=DB_SECRET)
    print("response_DB_SECRET: ", response_DB_SECRET)
    return json.loads(response_DB_SECRET["SecretString"])

def get_db_info():
    print("DB_INFO: ", DB_INFO)
    response_DB_INFO = secrets_client.get_secret_value(SecretId=DB_INFO)
    print("response_DB_INFO: ", response_DB_INFO)
    return json.loads(response_DB_INFO["SecretString"])


def insert_card_and_transaction(payload, db_secret, db_info):
    connection = None
    
    INIT_TYPE = 1
    TOP_UP_TYPE = 2
    
    try:
        connection = mysql.connector.connect(
            host=db_info["host"],
            user=db_secret["username"],
            password=db_secret["password"],
            database=db_info["database"],
            port=db_info.get("port", 3306),
        )

        cursor = connection.cursor()

        card_id = payload["Card_Id"]
        amount = payload["Amount"]

        user_id = payload.get("User_Id")
        if user_id == "":
            user_id = None

        # ---------- UPSERT CARD ----------
        upsert_card_sql = """
        INSERT INTO CARDS (CARD_ID, USER_ID, BALANCE)
        VALUES (%s, %s, %s)
        ON DUPLICATE KEY UPDATE
            USER_ID = COALESCE(VALUES(USER_ID), USER_ID),
            BALANCE = BALANCE + VALUES(BALANCE)
        """

        cursor.execute(
            upsert_card_sql,
            (card_id, user_id, amount),
        )

        # Determine transaction type
        if cursor.rowcount == 1:
            tx_type = INIT_TYPE      # card created
        else:
            tx_type = TOP_UP_TYPE    # card existed, balance increased

        # ---------- INSERT TRANSACTION ----------
        insert_tx_sql = """
        INSERT INTO TRANSACTIONS
        (CARD_ID, TYPE, AMOUNT, TRANSACTION_DATETIME)
        VALUES (%s, %s, %s, %s)
        """

        cursor.execute(
            insert_tx_sql,
            (
                card_id,
                tx_type,
                amount,
                datetime.utcnow(),
            ),
        )

        connection.commit()

    except Error as e:
        if connection:
            connection.rollback()
        raise e

    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()


def lambda_handler(event, context):
    db_secret = get_db_secret()
    db_info = get_db_info()

    for record in event["Records"]:
        body = json.loads(record["body"])
        insert_card_and_transaction(body, db_secret, db_info)

    return {
        "statusCode": 200,
        "body": "Records inserted successfully"
    }